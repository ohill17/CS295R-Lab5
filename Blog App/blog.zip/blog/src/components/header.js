import React from 'react';

function Header() {
  return (
    <div>
    
      <img src="your-header-image.jpg" alt="Header" />
    </div>
  );
}

export default Header;