import React, { useContext } from 'react';
import { UserContext } from '../context/user';
import { PostsContext } from '../context/posts';

function PostsList() {
  const { user } = useContext(UserContext);
  const { posts, featuredPosts } = useContext(PostsContext);

  const postsToRender = user ? posts : featuredPosts;


  console.log(postsToRender);

  return (
    <div>
      {postsToRender.map((post) => (
        <div key={post.id}>
          <h2>{post.title}</h2>
          <p>{post.content}</p>
        </div>
      ))}
    </div>
  );
}

export default PostsList;